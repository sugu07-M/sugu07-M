import { Component } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-updatechangerequest',
  templateUrl: './updatechangerequest.component.html',
  styleUrl: './updatechangerequest.component.css'
})
export class UpdatechangerequestComponent {
  showInitiator: boolean = false;
  showRiskQ: boolean = false;
  constructor(private http: HttpClient, private route: ActivatedRoute,private router:Router) { }

  ngOnInit(): void {
    this.getclassification();
    this.getcategory();
    this.getnature();
    this.getplant();
    this.getcrdata();
    this.getcategorytype();
    this.getreference();
    
    this.getidupdate();
    this.idcheck();
    this.getupdatyevalue(this.itcrid);
  }

  toggleInitiatorFields() {
    this.showInitiator = !this.showInitiator;
  }

  toggleField() {
    this.showRiskQ = !this.showRiskQ;
  }

  isPopupVisible = false;

  togglePopup() {
    this.isPopupVisible = !this.isPopupVisible;
  }
  // g*p classification
  plantData: any[] = []; // Assuming you want to store multiple plant data entries

  addMore() {
    this.plantData.push({
      selectPlant: '',
      controlNumber: '',
      controlDate: '',
      attachment: null
    });
  }

  update(index: number) {
    // Implement the update logic here
  }

  delete(index: number) {
    this.plantData.splice(index, 1);
  }

  handleFileInput(event: any, index: number) {
    // Assuming you want to handle file input for a specific row
    const file = event.target.files[0];
    this.plantData[index].attachment = file;
  }

  getidupdate() {
    this.itcrid = this.route.snapshot.paramMap.get('id');
  }

  itcrid: any = '';
  supportId: any = '';
  classificationId: any = '';
  categoryId: any = '';
  categorytypeid: any = '';
  crowner: any = '';
  crdate: any = '';
  changerequestedby: any = '';
  referenceid: any = '';
  referencetype: any = '';
  crinitiatedFor: any = '';
  changeType: any = '';
  natureOfChange: any = '';
  priorityType: any = '';
  plantId: any = '';
  gxpclassification: any = '';
  changeControlNo: any = '';
  changeControlDt: any = '';
  changeControlAttach: any = '';
  changeDesc: any = '';
  reasonForChange: any = '';
  alternateConsidetation: any = '';
  impactNotDoing: any = '';
  triggeredBy: any = '';
  benefits: any = '';
  estimatedCost: any = '';
  estimatedCostCurr: any = '';
  estimatedEffort: any = '';
  estimatedEffortUnit: any = '';
  estimatedDateCompletion: any = '';
  rollbackPlan: any = '';
  backoutPlan: any = '';
  downTimeRequired: any = '';
  downTimeFromDate: any = '';
  downTimeToDate: any = '';
  approvedBy: any = '';
  approvedDt: any = '';
  createdBy: any = '';
  createdDt: any = '';
  modifiedBy: any = '';
  modifiedDt: any = '';
  selectedCategory: any = '';
  changecntroldt: any = '';

  idcheck() {
    console.log(this.itcrid)
  }

  
  categorydata: any[] = [];

  getcategory() {
    const apiUrls = 'https://localhost:7236/api/Category'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        console.log(response);
        this.categorydata = response;
        console.log(this.categorydata)
      },
      (error) => {
        console.error("Post failed", error)
      }
    )
  }

  Natureofchange: any[] = [];

  getnature() {
  
    const apiUrls = 'https://localhost:7236/api/NatureofChange'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        console.log(response);
        this.Natureofchange = response;
        console.log(this.Natureofchange)
      },
      (error) => {
        console.error("Post failed", error)
      }
    )
  }

  classifications: any[] = [];

  getclassification() {

    const apiUrls = 'https://localhost:7236/api/Classification'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        console.log(response);
        this.classifications = response;
        console.log(this.classifications)
      },
      (error) => {
        console.error("Post failed", error)
      }
    )
  }

  plantcode: any[] = [];
  plant: any;
  getplant() {

    const apiUrls = 'https://localhost:7236/api/Plantid'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        console.log(response);
        this.plantcode = response;
        console.log(this.plantcode)
        
      },
      (error) => {
        console.error("Post failed", error)
      }
    )
  }

  changerequest: any[] = [];

  getcrdata() {

    const apiUrls = 'https://localhost:7236/api/ChangeRequest/Getrequest'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        console.log(response);
        this.changerequest = response;
        console.log(this.changerequest)
      },
      (error) => {
        console.error("Post failed", error)
      }
    )
  }
  
  systemlandscape: any[] = [];

  getsystemlandscape() {
 
    const apiUrls = 'https://localhost:7236/api/SystemLandscape'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        console.log(response);
        this.systemlandscape = response;
        console.log(this.systemlandscape)
      },
      (error) => {
        console.error("Post failed", error)
      }
    )
  }

  categorytype: any[] = [];

  getcategorytype() {

    const apiUrls = 'https://localhost:7236/api/CategoryTyp'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        console.log(response);
        this.categorytype = response;
        console.log(this.categorytype)
      },
      (error) => {
        console.error("Post failed", error)
      }
    )
  }

  referenceapi: any[] = [];
  updatevalue: any[] = [];
  getreference() {

    const apiUrls = 'https://localhost:7236/api/Classification'
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    this.http.get(apiUrls, requestBody).subscribe(
      (response: any) => {
        console.log(response);
        this.referenceapi = response;
        console.log(this.classifications)
      },
      (error) => {
        console.error("Post failed", error)
      }
    )
  }

  submitforapprove() {
    debugger
    const apiUrl = "https://localhost:7236/api/ChangeRequest/PassingModel/${this.itcrid}";
    const requestBody = {
      "type": "U",
      "supportId": 1,
      "classifcationId": this.classificationId,
      "categoryId": this.categoryId,
      "crowner": this.crowner,
      "crrequestedBy": this.changerequestedby,
      "referenceId": this.referenceid,
      "referenceTyp": this.referencetype,
      "crdate": this.crdate,
      "crinitiatedFor": this.crinitiatedFor,
      "status": "New",
      "changeType": this.categorytypeid,
      "natureOfChange": this.natureOfChange,
      "priorityType": this.priorityType,
      "plantId": this.plantId,
      "gxpclassification": true,
      "changeControlNo": this.changeControlNo,
      "changeControlDt": this.changeControlDt,
      "changeControlAttach": true,
      "changeDesc": this.changeDesc,
      "reasonForChange": this.reasonForChange,
      "alternateConsidetation": this.alternateConsidetation,
      "impactNotDoing": this.impactNotDoing,
      "triggeredBy": this.triggeredBy,
      "benefits": this.benefits,
      "estimatedCost": this.estimatedCost,
      "estimatedCostCurr": this.estimatedCostCurr,
      "estimatedEffort": this.estimatedEffort,
      "estimatedEffortUnit": this.estimatedEffortUnit,
      "estimatedDateCompletion": this.estimatedDateCompletion,
      "rollbackPlan": this.rollbackPlan,
      "backoutPlan": this.backoutPlan,
      "downTimeRequired": true,
      "downTimeFromDate": "2024-02-10T09:21:40.357Z",
      "downTimeToDate": "2024-02-10T09:21:40.357Z",
      "approvedBy": "string",
      "approvedDt": "string",
      "createdBy": "string",
      "createdDt": "2024-02-10T09:21:40.357Z",
      "modifiedBy": "string",
      "modifiedDt": "2024-02-10T09:21:40.357Z"
    }
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    };
    this.http.post(apiUrl, requestBody, httpOptions).subscribe(
      (response: any) => {
        console.log(response);
      },
      (error: any) => {
        console.log('Post request failed', error);
      }
    );
    this.router.navigate(['/change-request']);
  }

  getupdatyevalue(itcrid:any) {
    debugger
    const apiUrls:any = 'https://localhost:7236/api/ChangeRequest/Getrequest';
    const requestBody = {

    }
    const httpOptions = {
      headers: new HttpHeaders({
        'content-Type': 'application/json'
      })
    };
    
    this.http.get(apiUrls).subscribe(
      (response: any) => {
        console.log("Response from API:", response);

        // Log the itcrid value
        console.log("itcrid:", itcrid);

        this.updatevalue = response.filter((item: any) => item.itcrid.toString() === itcrid.toString());
        console.log("Update_value", this.updatevalue)
        /*if (this.itcrtd = this.updatevalue)*/
      },
      (error: any) => {
        console.log('Post request failed', error);
      }
    );
  }

  Updatecr() {

    const apiUrl = "https://localhost:7236/api/ChangeRequest/PassingModel/";
    const requestBody = { 
      "type": "U",
      "itcrid":this.itcrid,
      "supportId": 1,
      "classifcationId": this.classificationId,
      "categoryId": this.categoryId,
      "crowner": this.updatevalue[0].crowner,
      "crrequestedBy": this.updatevalue[0].changerequestedby,
      "referenceId": this.referenceid,
      "referenceTyp": this.updatevalue[0].referenceTyp,
      "crdate": this.crdate,
      "crinitiatedFor": this.updatevalue[0].crinitiatedFor,
      "status": "New",
      "categoryTypeId": this.categorytypeid,
      "natureOfChange": this.natureOfChange,
      "priorityType": this.priorityType,
      "plantId": this.plantId,
      "gxpclassification": true,
      "changeControlNo": this.updatevalue[0].changeControlNo,
      "changeControlDt": this.updatevalue[0].changeControlDt,
      "changeControlAttach": true,
      "changeDesc": this.updatevalue[0].changeDesc,
      "reasonForChange": this.updatevalue[0].reasonForChange,
      "alternateConsidetation": this.updatevalue[0].alternateConsidetation,
      "impactNotDoing": this.updatevalue[0].impactNotDoing,
      "triggeredBy": this.updatevalue[0].triggeredBy,
      "benefits": this.updatevalue[0].benefits,
      "estimatedCost": this.updatevalue[0].estimatedCost,
      "estimatedCostCurr": this.updatevalue[0].estimatedCostCurr,
      "estimatedEffort": this.updatevalue[0].estimatedEffort,
      "estimatedEffortUnit": this.updatevalue[0].estimatedEffortUnit,
      "estimatedDateCompletion": this.updatevalue[0].estimatedDateCompletion,
      "rollbackPlan": this.updatevalue[0].rollbackPlan,
      "backoutPlan": this.updatevalue[0].backoutPlan,
      "downTimeRequired": true,
      "downTimeFromDate": "2024-02-10T09:21:40.357Z",
      "downTimeToDate": "2024-02-10T09:21:40.357Z",
      "approvedBy": "string",
      "approvedDt": "string",
      "createdBy": "string",
      "createdDt": "2024-02-10T09:21:40.357Z",
      "modifiedBy": "string",
      "modifiedDt": "2024-02-10T09:21:40.357Z"
    }
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    };
    this.http.post(apiUrl, requestBody, httpOptions).subscribe(
      (response: any) => {
        console.log(response);
      },
      (error: any) => {
        console.log('Post request failed', error);
      }
    );
    this.router.navigate(['/change-request']);
  }

}
